# Lab 7 Implementation Notes
## Part 1: Generate the Lab 7 Application
## AI prompt used

> Generate code for all user management use cases UM-01 through UM-10 in the User Management Design Document.
>
> Use the Application Builder, Test Harness Generator, and Traceability Auditor documents as implementation guidance. Follow the authentication, authorization, session management, password hashing, CSRF protection, and role based access practices in the Authentication Reading Handout.
>
> Use lab6.zip as the existing Peer Tutoring Hub application to extend. Preserve the Lab 6 three tier architecture and update the application as needed to support user registration, login, logout, profile management, administrator access, and protected tutoring request workflows.
>
> Return a complete Lab 7 application package with all updated and new files.

## Uploaded source files

- `application-builder.txt`
- `IS6465_Authentication_Reading_Handout_v1.2_[16Nov2026].pdf`
- `lab6.zip`
- `Peer_Tutoring_Hub_User_Management_With_Diagrams.docx`
- `test-harness-generator.txt`
- `traceability-auditor.txt`

## How Lab 7 extends Lab 6

Lab 7 keeps the existing PHP, PDO, and SQLite three tier structure and tutoring request tables. It adds a `users` table for account credentials, roles, and statuses, connected to the existing `students` records through `students.user_id`. New pages and services support Student/Tutor registration, login/logout, own-profile and password changes, and Administrator user search and management. The existing tutoring request flow now requires authentication: Students can manage their own requests, Administrators can review all requests, and Tutors are denied request access.

## Example checked against the design and handout

In `includes/auth.php::requireLogin()`, protected requests check for a signed-in user, end sessions after 1,200 seconds of inactivity, reload the account from SQLite, and reject missing or inactive accounts. The helper then refreshes the session's display name and role from the database. I checked this implementation against the Authentication Reading Handout's reusable session-check example, which requires a 20-minute inactivity timeout and a fresh account/status/role check on every protected request.

## Verification note

PHP syntax checks passed for the package. The CLI test scripts are included but were not run, so runtime behavior has not been verified.

## Part 2: Set Up the Database

Open a terminal in GitHub Codespaces and move into the Lab 7 database folder:

```bash
cd lab7/database
```

Create the Lab 6 database structure:

```bash
sqlite3 tutoring.db < setup-database.sql
```

Upgrade the database for user management:

```bash
sqlite3 tutoring.db < upgrade-to-user-management.sql
```

Open the database and list its tables:

```bash
sqlite3 tutoring.db
```

At the SQLite prompt:

```text
@jamisonorton ➜ .../IS_Masters/IS_6465_WebApp/lab7/database (main) $ sqlite3 tutoring.db < setup-database.sql
@jamisonorton ➜ .../IS_Masters/IS_6465_WebApp/lab7/database (main) $ sqlite3 tutoring.db < upgrade-to-user-management.sql
@jamisonorton ➜ .../IS_Masters/IS_6465_WebApp/lab7/database (main) $ sqlite3 tutoring.db
SQLite version 3.53.2 2026-06-03 19:12:13
Enter ".help" for usage hints.
sqlite> .tables
students     tutoring_requests     users
sqlite> .quit
```

**Confirmation:** The Codespaces terminal output above shows all three expected tables: `students`, `tutoring_requests`, and `users`.

## Part 3: Create an Administrator Account

From the `lab7/database` folder, I used this command structure. The password is redacted:

```bash
php create-admin.php "Test Administrator" admin@example.com "<12+ character test password>"
```

The script prompted for the account details in that run. It confirmed: `Administrator account created with user ID 1.`

- **Test account email:** `testingadmin@example.com`
- **Assigned role:** Administrator

## Part 4: Run the Application

From the `lab7/database` folder, return to the `lab7` project root and start the PHP development server:

```bash
cd ..
php -S 0.0.0.0:8000
```

Open port 8000 in the browser.

- **Browser URL opened:** [http://127.0.0.1:8000/IS_6465_WebApp/lab7/php/login.php](http://127.0.0.1:8000/IS_6465_WebApp/lab7/php/login.php)
- **Result:** The Peer Tutoring Hub application opened successfully.
- **Unauthenticated access:** When I first accessed a protected page without logging in, the application redirected me to the login page instead of showing protected content.

## Part 5: Test the Student Workflow

The student registration and login succeeded, and the profile screenshot below shows the signed-in Student account. The Request a Session link initially returned a file-not-found page. I updated the navbar links to preserve the application's folder path; the request steps still need to be retried in Codespaces.

| Test | What I Did | Expected Result | Actual Result | Pass or Fail |
|---|---|---|---|---|
| Register student account | Registered Jamison Test with a test account. | Student account is created. | Account was created; profile shows role Student and status Active. | Pass |
| Log in as student | Logged in with the new student account. | Student can access protected student pages. | The student profile page opened. | Pass |
| View or update profile | Opened My Profile. | Profile information is displayed or saved. | Name, email, role, and status were displayed (see screenshot). | Pass |
| Create tutoring request | Selected Request a Session in the navbar. | A new request is created with status `Open`. | The link returned a file-not-found page. Navbar path handling has been corrected; this step still needs a Codespaces retest. | Fail — retest pending |
| Edit Open request | Not attempted because no request was created. | Updated request information is displayed. | Blocked until a request can be created. | Not tested |
| View my requests | Not attempted because no request was created. | Student sees the student’s own requests. | Blocked until a request can be created. | Not tested |
| Log out | Not attempted during this run. | Session ends and login page appears. | Not tested. | Not tested |

![Signed-in student profile](screenshots/student-profile.png)
